#ifndef __APP_KB_AND_LS_H_
#define __APP_KB_AND_LS_H_

void app_kb_callback_scanner();

void app_keyboard();

#endif //__APP_KB_AND_LS_H_
