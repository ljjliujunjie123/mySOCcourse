#ifndef __APP_BMP_H_
#define __APP_BMP_H_

int bmp_DisplayBmpFile(char* filename);

void bmp_BmpViewerMain();

void bmp_LogViewer();

void bmp_display(char *filename);

#endif
