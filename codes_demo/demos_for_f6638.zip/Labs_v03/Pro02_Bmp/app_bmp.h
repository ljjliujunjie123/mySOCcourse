#ifndef __APP_BMP_H_
#define __APP_BMP_H_

int bmp_DisplayBmpFile(char* filename);

#endif
