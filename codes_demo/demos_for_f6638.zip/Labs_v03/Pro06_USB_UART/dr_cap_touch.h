#ifndef __DR_CAP_TOUCH_H_
#define __DR_CAP_TOUCH_H_

#include <stdint.h>

void initCapTouch();
uint16_t CapTouch_ReadChannel(int i);

#endif
